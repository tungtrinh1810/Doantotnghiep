#include "main.h"
#ifndef BUTTON3
#define BUTTON3
void button_handle3(void);
void button_init3(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin);
#endif

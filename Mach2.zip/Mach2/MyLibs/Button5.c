#include "button5.h"

uint8_t btn_curent5;
uint8_t btn_last5 = 1;
uint8_t btn_filter5 = 1;
uint32_t t_debounce5;
uint32_t t_start_press5, t_time_out5, t_double_click5;
uint16_t t_repeate_timeout5;
uint16_t t_timeout_press5;
GPIO_TypeDef *GPIOx5;
uint16_t GPIO_Pin5;

__attribute__((weak)) void btn_pressing_callback5(){}
__attribute__((weak)) void btn_press_short_callback5(){}
__weak void btn_press_long_callback5(uint16_t time_press){}
__weak void btn_realease_callback5(){}
__weak void btn_pressing_timeout_callback5(uint16_t time_press){}
__weak void btn_double_click_callback5(){}

void button_handle5()
{
	uint8_t sta5 = HAL_GPIO_ReadPin(GPIOx5,GPIO_Pin5);
	if(sta5 != btn_filter5)
	{
		btn_filter5 = sta5;
		t_debounce5 = HAL_GetTick();
	}
	if(HAL_GetTick() - t_debounce5 >= 15)
	{
		btn_curent5 = btn_filter5;
		if(btn_curent5 != btn_last5)
		{
			if(btn_curent5 == 0)
			{
				t_start_press5 = HAL_GetTick();
				t_time_out5 = t_start_press5;
				t_repeate_timeout5 = 3000;
				t_timeout_press5 = t_repeate_timeout5;
				btn_pressing_callback5();
			}
			else //nha nut
			{
				uint16_t time_pressed5 = HAL_GetTick() -t_start_press5;
			  if(time_pressed5 <= 1000)
			  {
					if(HAL_GetTick() - t_double_click5 <= 500)
					{
						btn_double_click_callback5();
					}
					t_double_click5 = HAL_GetTick();
					btn_press_short_callback5();
			  }
				else
				{
				 btn_press_long_callback5(time_pressed5);
				}
				btn_realease_callback5();
			}
			btn_last5 = btn_curent5;
		}
		if((btn_curent5 ==0) && (HAL_GetTick() - t_time_out5 >= t_repeate_timeout5))
		{
			btn_pressing_timeout_callback5(t_timeout_press5);
			t_repeate_timeout5 = 1000;
			t_timeout_press5 += t_repeate_timeout5;
			t_time_out5 = HAL_GetTick();
		}
	}
}
void button_init5(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin)
{
	GPIOx5 = _GPIOx;
	GPIO_Pin5 = _GPIO_Pin;
}
#include "main.h"
#ifndef BUTTON1
#define BUTTON1
void button_handle1(void);
void button_init1(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin);
#endif

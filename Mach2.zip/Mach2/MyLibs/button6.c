#include "button6.h"

uint8_t btn_curent6;
uint8_t btn_last6 = 1;
uint8_t btn_filter6 = 1;
uint32_t t_debounce6;
uint32_t t_start_press6, t_time_out6, t_double_click6;
uint16_t t_repeate_timeout6;
uint16_t t_timeout_press6;
GPIO_TypeDef *GPIOx6;
uint16_t GPIO_Pin6;

__attribute__((weak)) void btn_pressing_callback6(){}
__attribute__((weak)) void btn_press_short_callback6(){}
__weak void btn_press_long_callback6(uint16_t time_press){}
__weak void btn_realease_callback6(){}
__weak void btn_pressing_timeout_callback6(uint16_t time_press){}
__weak void btn_double_click_callback6(){}

void button_handle6()
{
	uint8_t sta6 = HAL_GPIO_ReadPin(GPIOx6,GPIO_Pin6);
	if(sta6 != btn_filter6)
	{
		btn_filter6 = sta6;
		t_debounce6 = HAL_GetTick();
	}
	if(HAL_GetTick() - t_debounce6 >= 15)
	{
		btn_curent6 = btn_filter6;
		if(btn_curent6 != btn_last6)
		{
			if(btn_curent6 == 0)
			{
				t_start_press6 = HAL_GetTick();
				t_time_out6 = t_start_press6;
				t_repeate_timeout6 = 3000;
				t_timeout_press6 = t_repeate_timeout6;
				btn_pressing_callback6();
			}
			else //nha nut
			{
				uint16_t time_pressed6 = HAL_GetTick() -t_start_press6;
			  if(time_pressed6 <= 1000)
			  {
					if(HAL_GetTick() - t_double_click6 <= 500)
					{
						btn_double_click_callback6();
					}
					t_double_click6 = HAL_GetTick();
					btn_press_short_callback6();
			  }
				else
				{
				 btn_press_long_callback6(time_pressed6);
				}
				btn_realease_callback6();
			}
			btn_last6 = btn_curent6;
		}
		if((btn_curent6 ==0) && (HAL_GetTick() - t_time_out6 >= t_repeate_timeout6))
		{
			btn_pressing_timeout_callback6(t_timeout_press6);
			t_repeate_timeout6 = 1000;
			t_timeout_press6 += t_repeate_timeout6;
			t_time_out6 = HAL_GetTick();
		}
	}
}
void button_init6(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin)
{
	GPIOx6 = _GPIOx;
	GPIO_Pin6 = _GPIO_Pin;
}
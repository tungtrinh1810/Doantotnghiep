#include "main.h"
#ifndef BUTTON6
#define BUTTON6
void button_handle6(void);
void button_init6(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin);
#endif
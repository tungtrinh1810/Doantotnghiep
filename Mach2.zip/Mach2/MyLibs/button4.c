#include "button4.h"

uint8_t btn_curent4;
uint8_t btn_last4 = 1;
uint8_t btn_filter4 = 1;
uint32_t t_debounce4;
uint32_t t_start_press4, t_time_out4, t_double_click4;
uint16_t t_repeate_timeout4;
uint16_t t_timeout_press4;
GPIO_TypeDef *GPIOx4;
uint16_t GPIO_Pin4;

__attribute__((weak)) void btn_pressing_callback4(){}
__attribute__((weak)) void btn_press_short_callback4(){}
__weak void btn_press_long_callback4(uint16_t time_press){}
__weak void btn_realease_callback4(){}
__weak void btn_pressing_timeout_callback4(uint16_t time_press){}
__weak void btn_double_click_callback4(){}

void button_handle4()
{
	uint8_t sta4 = HAL_GPIO_ReadPin(GPIOx4,GPIO_Pin4);
	if(sta4 != btn_filter4)
	{
		btn_filter4 = sta4;
		t_debounce4 = HAL_GetTick();
	}
	if(HAL_GetTick() - t_debounce4 >= 15)
	{
		btn_curent4 = btn_filter4;
		if(btn_curent4 != btn_last4)
		{
			if(btn_curent4 == 0)
			{
				t_start_press4 = HAL_GetTick();
				t_time_out4 = t_start_press4;
				t_repeate_timeout4 = 3000;
				t_timeout_press4 = t_repeate_timeout4;
				btn_pressing_callback4();
			}
			else //nha nut
			{
				uint16_t time_pressed4 = HAL_GetTick() -t_start_press4;
			  if(time_pressed4 <= 1000)
			  {
					if(HAL_GetTick() - t_double_click4 <= 500)
					{
						btn_double_click_callback4();
					}
					t_double_click4 = HAL_GetTick();
					btn_press_short_callback4();
			  }
				else
				{
				 btn_press_long_callback4(time_pressed4);
				}
				btn_realease_callback4();
			}
			btn_last4 = btn_curent4;
		}
		if((btn_curent4 ==0) && (HAL_GetTick() - t_time_out4 >= t_repeate_timeout4))
		{
			btn_pressing_timeout_callback4(t_timeout_press4);
			t_repeate_timeout4 = 1000;
			t_timeout_press4 += t_repeate_timeout4;
			t_time_out4 = HAL_GetTick();
		}
	}
}
void button_init4(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin)
{
	GPIOx4 = _GPIOx;
	GPIO_Pin4 = _GPIO_Pin;
}
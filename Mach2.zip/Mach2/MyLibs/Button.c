#include "button.h"

//var button
uint8_t btn_curent;
uint8_t btn_last = 1;
uint8_t btn_filter = 1;
uint32_t t_debounce;
uint32_t t_start_press, t_time_out, t_double_click;
uint16_t t_repeate_timeout;
uint16_t t_timeout_press;
GPIO_TypeDef *GPIOx;
uint16_t GPIO_Pin;

__attribute__((weak)) void btn_pressing_callback(){}
__attribute__((weak)) void btn_press_short_callback(){}
__weak void btn_press_long_callback(uint16_t time_press){}
__weak void btn_realease_callback(){}
__weak void btn_pressing_timeout_callback(uint16_t time_press){}
__weak void btn_double_click_callback(){}
	
void button_handle()
{
	uint8_t sta = HAL_GPIO_ReadPin(GPIOx,GPIO_Pin);
	if(sta != btn_filter)
	{
		btn_filter = sta;
		t_debounce = HAL_GetTick();
	}
	if(HAL_GetTick() - t_debounce >= 15)
	{
		btn_curent = btn_filter;
		if(btn_curent != btn_last)
		{
			if(btn_curent == 0)
			{
				t_start_press = HAL_GetTick();
				t_time_out = t_start_press;
				t_repeate_timeout = 3000;
				t_timeout_press = t_repeate_timeout;
				btn_pressing_callback();
			}
			else //nha nut
			{
				uint16_t time_pressed = HAL_GetTick() -t_start_press;
			  if(time_pressed <= 1000)
			  {
					if(HAL_GetTick() - t_double_click <= 500)
					{
						btn_double_click_callback();
					}
					t_double_click = HAL_GetTick();
					btn_press_short_callback();
			  }
				else
				{
				 btn_press_long_callback(time_pressed);
				}
				btn_realease_callback();
			}
			btn_last = btn_curent;
		}
		if((btn_curent ==0) && (HAL_GetTick() - t_time_out >= t_repeate_timeout))
		{
			btn_pressing_timeout_callback(t_timeout_press);
			t_repeate_timeout = 1000;
			t_timeout_press += t_repeate_timeout;
			t_time_out = HAL_GetTick();
		}
	}
}
void button_init(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin)
{
	GPIOx = _GPIOx;
	GPIO_Pin = _GPIO_Pin;
}

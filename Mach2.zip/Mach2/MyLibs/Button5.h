#include "main.h"
#ifndef BUTTON5
#define BUTTON5
void button_handle5(void);
void button_init5(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin);
#endif
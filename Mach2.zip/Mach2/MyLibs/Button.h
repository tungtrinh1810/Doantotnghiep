#include "main.h"
#ifndef BUTTON
#define BUTTOn
void button_handle(void);
void button_init(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin);
#endif

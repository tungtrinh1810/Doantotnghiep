#include "main.h"
#ifndef BUTTON4
#define BUTTON4
void button_handle4(void);
void button_init4(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin);
#endif

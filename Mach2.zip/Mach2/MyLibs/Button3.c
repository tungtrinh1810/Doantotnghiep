#include "button3.h"

uint8_t btn_curent3;
uint8_t btn_last3 = 1;
uint8_t btn_filter3 = 1;
uint32_t t_debounce3;
uint32_t t_start_press3, t_time_out3, t_double_click3;
uint16_t t_repeate_timeout3;
uint16_t t_timeout_press3;
GPIO_TypeDef *GPIOx3;
uint16_t GPIO_Pin3;

__attribute__((weak)) void btn_pressing_callback3(){}
__attribute__((weak)) void btn_press_short_callback3(){}
__weak void btn_press_long_callback3(uint16_t time_press){}
__weak void btn_realease_callback3(){}
__weak void btn_pressing_timeout_callback3(uint16_t time_press){}
__weak void btn_double_click_callback3(){}

void button_handle3()
{
	uint8_t sta3 = HAL_GPIO_ReadPin(GPIOx3,GPIO_Pin3);
	if(sta3 != btn_filter3)
	{
		btn_filter3 = sta3;
		t_debounce3 = HAL_GetTick();
	}
	if(HAL_GetTick() - t_debounce3 >= 15)
	{
		btn_curent3 = btn_filter3;
		if(btn_curent3 != btn_last3)
		{
			if(btn_curent3 == 0)
			{
				t_start_press3 = HAL_GetTick();
				t_time_out3 = t_start_press3;
				t_repeate_timeout3 = 3000;
				t_timeout_press3 = t_repeate_timeout3;
				btn_pressing_callback3();
			}
			else //nha nut
			{
				uint16_t time_pressed3 = HAL_GetTick() -t_start_press3;
			  if(time_pressed3 <= 1000)
			  {
					if(HAL_GetTick() - t_double_click3 <= 500)
					{
						btn_double_click_callback3();
					}
					t_double_click3 = HAL_GetTick();
					btn_press_short_callback3();
			  }
				else
				{
				 btn_press_long_callback3(time_pressed3);
				}
				btn_realease_callback3();
			}
			btn_last3 = btn_curent3;
		}
		if((btn_curent3 ==0) && (HAL_GetTick() - t_time_out3 >= t_repeate_timeout3))
		{
			btn_pressing_timeout_callback3(t_timeout_press3);
			t_repeate_timeout3 = 1000;
			t_timeout_press3 += t_repeate_timeout3;
			t_time_out3 = HAL_GetTick();
		}
	}
}
void button_init3(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin)
{
	GPIOx3 = _GPIOx;
	GPIO_Pin3 = _GPIO_Pin;
}
#include "button2.h"

uint8_t btn_curent1;
uint8_t btn_last1 = 1;
uint8_t btn_filter1 = 1;
uint32_t t_debounce1;
uint32_t t_start_press1, t_time_out1, t_double_click1;
uint16_t t_repeate_timeout1;
uint16_t t_timeout_press1;
GPIO_TypeDef *GPIOx1;
uint16_t GPIO_Pin1;

__attribute__((weak)) void btn_pressing_callback1(){}
__attribute__((weak)) void btn_press_short_callback1(){}
__weak void btn_press_long_callback1(uint16_t time_press){}
__weak void btn_realease_callback1(){}
__weak void btn_pressing_timeout_callback1(uint16_t time_press){}
__weak void btn_double_click_callback1(){}

void button_handle1()
{
	uint8_t sta1 = HAL_GPIO_ReadPin(GPIOx1,GPIO_Pin1);
	if(sta1 != btn_filter1)
	{
		btn_filter1 = sta1;
		t_debounce1 = HAL_GetTick();
	}
	if(HAL_GetTick() - t_debounce1 >= 15)
	{
		btn_curent1 = btn_filter1;
		if(btn_curent1 != btn_last1)
		{
			if(btn_curent1 == 0)
			{
				t_start_press1 = HAL_GetTick();
				t_time_out1 = t_start_press1;
				t_repeate_timeout1 = 3000;
				t_timeout_press1 = t_repeate_timeout1;
				btn_pressing_callback1();
			}
			else //nha nut
			{
				uint16_t time_pressed1 = HAL_GetTick() -t_start_press1;
			  if(time_pressed1 <= 1000)
			  {
					if(HAL_GetTick() - t_double_click1 <= 500)
					{
						btn_double_click_callback1();
					}
					t_double_click1 = HAL_GetTick();
					btn_press_short_callback1();
			  }
				else
				{
				 btn_press_long_callback1(time_pressed1);
				}
				btn_realease_callback1();
			}
			btn_last1 = btn_curent1;
		}
		if((btn_curent1 ==0) && (HAL_GetTick() - t_time_out1 >= t_repeate_timeout1))
		{
			btn_pressing_timeout_callback1(t_timeout_press1);
			t_repeate_timeout1 = 1000;
			t_timeout_press1 += t_repeate_timeout1;
			t_time_out1 = HAL_GetTick();
		}
	}
}
void button_init1(GPIO_TypeDef *_GPIOx, uint16_t _GPIO_Pin)
{
	GPIOx1 = _GPIOx;
	GPIO_Pin1 = _GPIO_Pin;
}